package com.smartherd.my_kotlin_app

data class Project(val title: String, val description: String)
