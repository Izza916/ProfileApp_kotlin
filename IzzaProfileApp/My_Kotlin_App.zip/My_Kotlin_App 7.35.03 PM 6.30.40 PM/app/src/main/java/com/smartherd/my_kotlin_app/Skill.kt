package com.smartherd.my_kotlin_app

data class Skill(
    val name: String,
    val percent: Int
)
